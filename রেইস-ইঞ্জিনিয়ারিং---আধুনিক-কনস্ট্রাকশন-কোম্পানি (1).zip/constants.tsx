
import React from 'react';
import { Building2, Home, Hammer, Palette, Ruler, Truck, Lightbulb, ClipboardCheck, HardHat, CheckCircle2 } from 'lucide-react';
import { Project, Service, NavItem } from './types';

export const NAV_ITEMS: NavItem[] = [
  { label: 'হোম', path: '/' },
  { label: 'আমাদের সম্পর্কে', path: '/about' },
  { label: 'সেবাসমূহ', path: '/services' },
  { label: 'পোর্টফোলিও', path: '/portfolio' },
  { label: 'যোগাযোগ', path: '/contact' }
];

export const SERVICES: Service[] = [
  {
    id: 1,
    title: 'আবাসিক নির্মাণ',
    icon: 'Home',
    description: 'আধুনিক সুযোগ-সুবিধা সম্পন্ন মানসম্মত আবাসিক ভবন এবং ভিলা নির্মাণ করি আমরা।'
  },
  {
    id: 2,
    title: 'বাণিজ্যিক প্রকল্প',
    icon: 'Building2',
    description: 'অফিস বিল্ডিং, শপিং মল এবং ইন্ডাস্ট্রিয়াল স্ট্রাকচার নির্মাণে আমাদের রয়েছে বিশেষ দক্ষতা।'
  },
  {
    id: 3,
    title: 'ইন্টেরিয়র ডিজাইন',
    icon: 'Palette',
    description: 'আপনার ঘর বা অফিসের ভেতরটাকে নান্দনিকভাবে সাজিয়ে তোলার দায়িত্ব আমাদের।'
  },
  {
    id: 4,
    title: 'ইঞ্জিনিয়ারিং কনসালটেন্সি',
    icon: 'Ruler',
    description: 'স্ট্রাকচারাল ডিজাইন এবং আর্কিটেকচারাল প্ল্যানিং এর জন্য আমরা সেরা সমাধান প্রদান করি।'
  },
  {
    id: 5,
    title: 'রেমডেলিং ও সংস্কার',
    icon: 'Hammer',
    description: 'পুরাতন বাড়িকে আধুনিক ছোঁয়ায় নতুনের মতো সাজিয়ে তুলতে আমাদের বিকল্প নেই।'
  },
  {
    id: 6,
    title: 'ম্যাটেরিয়াল সাপ্লাই',
    icon: 'Truck',
    description: 'নির্মাণ কাজের জন্য প্রয়োজনীয় উচ্চমানের কাঁচামাল এবং উপকরণ সরবরাহ করি।'
  }
];

export const PROCESS_STEPS = [
  {
    title: 'পরিকল্পনা ও আইডিয়া',
    desc: 'আপনার চাহিদার ভিত্তিতে আমরা প্রাথমিক নকশা এবং পরিকল্পনা তৈরি করি।',
    icon: Lightbulb,
    color: 'bg-yellow-500'
  },
  {
    title: 'ডিজাইন ও আর্কিটেকচার',
    desc: 'আধুনিক ও নিখুঁত আর্কিটেকচারাল ড্রয়িং এর মাধ্যমে চূড়ান্ত ডিজাইন প্রস্তুত করি।',
    icon: Palette,
    color: 'bg-blue-500'
  },
  {
    title: 'নির্মাণ কার্যক্রম',
    desc: 'আমাদের অভিজ্ঞ ইঞ্জিনিয়ারদের তত্ত্বাবধানে শুরু হয় মূল নির্মাণ কাজ।',
    icon: HardHat,
    color: 'bg-orange-500'
  },
  {
    title: 'ফিনিশিং ও হ্যান্ডওভার',
    desc: 'সর্বোচ্চ গুণমান নিশ্চিত করে নির্দিষ্ট সময়ের মধ্যে আপনার প্রজেক্ট বুঝিয়ে দিই।',
    icon: CheckCircle2,
    color: 'bg-green-500'
  }
];

export const TESTIMONIALS = [
  {
    name: 'আহমেদ চৌধুরী',
    role: 'ব্যবস্থাপনা পরিচালক, ভিশন গ্রুপ',
    comment: 'রেইস ইঞ্জিনিয়ারিং আমাদের অফিস বিল্ডিং প্রজেক্টটি অসাধারনভাবে সম্পন্ন করেছে। তাদের কাজের মান এবং শৃঙ্খলা প্রশংসনীয়।',
    image: 'https://i.pravatar.cc/150?u=a'
  },
  {
    name: 'ফারহানা ইসলাম',
    role: 'গৃহিনী',
    comment: 'আমার স্বপ্নের বাড়িটি ঠিক যেমনটা চেয়েছিলাম, রেইস ইঞ্জিনিয়ারিং তার চেয়েও সুন্দর করে তৈরি করে দিয়েছে।',
    image: 'https://i.pravatar.cc/150?u=b'
  },
  {
    name: 'মোঃ কামরুল হাসান',
    role: 'আর্কিটেক্ট',
    comment: 'একজন প্রফেশনাল হিসেবে আমি তাদের টেকনিক্যাল দক্ষতা এবং ডিজাইনের সূক্ষ্মতার প্রশংসা করি।',
    image: 'https://i.pravatar.cc/150?u=c'
  }
];

export const PROJECTS: Project[] = [
  {
    id: 1,
    title: 'গুলশান লেক ভিউ টাওয়ার',
    category: 'আবাসিক',
    image: 'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&q=80&w=800',
    description: 'একটি আধুনিক ২০ তলা আবাসিক প্রকল্প যা গুলশান লেকের পাশে অবস্থিত।'
  },
  {
    id: 2,
    title: 'উত্তরা বিজনেস হাব',
    category: 'বাণিজ্যিক',
    image: 'https://images.unsplash.com/photo-1497366216548-37526070297c?auto=format&fit=crop&q=80&w=800',
    description: 'আধুনিক অফিস স্পেস এবং কনফারেন্স রুম সমৃদ্ধ একটি কর্পোরেট বিল্ডিং।'
  },
  {
    id: 3,
    title: 'বনানী লাক্সারি অ্যাপার্টমেন্ট',
    category: 'আবাসিক',
    image: 'https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?auto=format&fit=crop&q=80&w=800',
    description: 'বিলাসবহুল ইন্টেরিয়র এবং স্মার্ট হোম ফিচারে সমৃদ্ধ একটি প্রজেক্ট।'
  },
  {
    id: 4,
    title: 'পূর্বাচল মডেল টাউন ভিলা',
    category: 'আবাসিক',
    image: 'https://images.unsplash.com/photo-1512917774080-9991f1c4c750?auto=format&fit=crop&q=80&w=800',
    description: 'প্রকৃতির কাছাকাছি নিরিবিলি পরিবেশে একটি আধুনিক ডুপ্লেক্স বাড়ি।'
  }
];

export const CONTACT_INFO = {
  address: 'বাড়ি নং ৪৫, রোড নং ১২, বনানী, ঢাকা-১২১৩',
  phone: '+৮৮০ ১৭১২-৩৪৫৬৭৮',
  email: 'info@raisengineering.com',
  openingHours: 'শনি - বৃহস্পতি: সকাল ৯:০০ - সন্ধ্যা ৬:০০'
};
