
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { ArrowRight, Sparkles, Building, Users, Clock, Award, PlayCircle, CheckCircle2 } from 'lucide-react';
import { SERVICES, PROJECTS } from '../constants';
import { getConstructionAdvice } from '../services/geminiService';

const Home: React.FC = () => {
  const [aiQuery, setAiQuery] = useState('');
  const [aiResponse, setAiResponse] = useState('');
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const handleAiSearch = async () => {
    if (!aiQuery.trim()) return;
    setLoading(true);
    setAiResponse('');
    try {
      const result = await getConstructionAdvice(aiQuery);
      setAiResponse(result);
    } catch (err) {
      setAiResponse("সিস্টেমে ত্রুটি হয়েছে। আবার চেষ্টা করুন।");
    } finally {
      setLoading(false);
    }
  };

  const fadeInUp = {
    initial: { opacity: 0, y: 30 },
    whileInView: { opacity: 1, y: 0 },
    viewport: { once: true },
    transition: { duration: 0.6 }
  };

  return (
    <div className="overflow-hidden bg-white">
      {/* Hero Section */}
      <section className="relative h-screen flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0">
          <img 
            src="https://images.unsplash.com/photo-1541888946425-d81bb19240f5?auto=format&fit=crop&q=80&w=2070" 
            alt="Construction" 
            className="w-full h-full object-cover scale-105"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-blue-950/90 to-blue-900/40" />
        </div>

        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-white">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
          >
            <h1 className="text-5xl md:text-8xl font-bold leading-tight mb-8">
              আপনার স্বপ্নের বাড়ি <br />
              <span className="text-orange-500">আমাদের দায়িত্ব</span>
            </h1>
            <p className="text-xl md:text-2xl mb-12 max-w-2xl text-gray-100 font-light">
              আধুনিক প্রযুক্তি এবং অভিজ্ঞ ইঞ্জিনিয়ারের সমন্বয়ে আমরা নির্মাণ করি আগামী দিনের সেরা স্থাপনা। আপনার স্বপ্নের শুরু হোক আমাদের হাত ধরে।
            </p>
            <div className="flex flex-col sm:flex-row gap-6">
              <motion.button 
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="bg-orange-500 hover:bg-orange-600 text-white px-10 py-5 rounded-2xl text-lg font-bold transition-all shadow-xl flex items-center justify-center"
              >
                কাজ শুরু করুন <ArrowRight className="ml-2" />
              </motion.button>
              <motion.button 
                whileHover={{ backgroundColor: "rgba(255,255,255,0.2)" }}
                className="bg-white/10 backdrop-blur-md text-white border border-white/30 px-10 py-5 rounded-2xl text-lg font-bold transition-all flex items-center justify-center"
              >
                <PlayCircle className="mr-2" /> ভিডিও দেখুন
              </motion.button>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 bg-white border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid grid-cols-2 md:grid-cols-4 gap-10">
          {[
            { label: 'সফল প্রজেক্ট', value: '৫০০+', icon: Building, color: 'text-blue-600' },
            { label: 'সন্তুষ্ট গ্রাহক', value: '৪৫০+', icon: Users, color: 'text-orange-600' },
            { label: 'অভিজ্ঞতা', value: '১০+ বছর', icon: Clock, color: 'text-green-600' },
            { label: 'অ্যাওয়ার্ড', value: '২৫+', icon: Award, color: 'text-purple-600' },
          ].map((stat, idx) => (
            <motion.div 
              key={idx}
              {...fadeInUp}
              transition={{ delay: idx * 0.1 }}
              className="text-center"
            >
              <div className={`${stat.color} mb-4 flex justify-center`}>
                <stat.icon size={36} />
              </div>
              <div className="text-4xl font-bold text-gray-900 mb-2">{stat.value}</div>
              <div className="text-gray-500 font-medium">{stat.label}</div>
            </motion.div>
          ))}
        </div>
      </section>

      {/* AI Estimator Section */}
      <section className="py-24 bg-gray-50">
        <div className="max-w-4xl mx-auto px-4">
          <motion.div 
            {...fadeInUp}
            className="bg-blue-950 rounded-[3rem] p-10 md:p-16 shadow-2xl relative overflow-hidden"
          >
            <div className="absolute top-0 right-0 p-10 opacity-10">
              <Sparkles size={120} className="text-white" />
            </div>
            
            <div className="text-center mb-12 relative z-10">
              <h2 className="text-3xl md:text-5xl font-bold text-white mb-4">এআই ইঞ্জিনিয়ারের পরামর্শ</h2>
              <p className="text-blue-200">আপনার নির্মাণ সংক্রান্ত যেকোনো প্রশ্ন করুন, আমাদের AI দিবে নিখুঁত পরামর্শ।</p>
            </div>

            <div className="flex flex-col md:flex-row gap-4 mb-10 relative z-10">
              <input 
                type="text" 
                value={aiQuery}
                onChange={(e) => setAiQuery(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && handleAiSearch()}
                placeholder="যেমন: ১০০০ স্কয়ার ফিট ডুপ্লেক্স বাড়ির খরচ কত?"
                className="flex-grow p-6 rounded-2xl bg-white/10 border border-white/20 text-white placeholder-white/40 focus:bg-white/20 outline-none transition-all text-lg backdrop-blur-md"
              />
              <button 
                onClick={handleAiSearch}
                disabled={loading}
                className="bg-orange-500 text-white px-10 py-5 rounded-2xl font-bold hover:bg-orange-400 transition-all shadow-xl disabled:opacity-50 flex items-center justify-center whitespace-nowrap"
              >
                {loading ? 'খুঁজছি...' : 'পরামর্শ নিন'}
              </button>
            </div>

            <AnimatePresence>
              {aiResponse && (
                <motion.div 
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0 }}
                  className="bg-white p-8 rounded-[2rem] shadow-xl text-gray-700 leading-relaxed whitespace-pre-wrap border border-blue-100"
                >
                  <div className="flex items-center mb-6 text-orange-600 font-bold border-b pb-4">
                    <CheckCircle2 className="mr-2" size={24} /> বিশেষজ্ঞের পরামর্শ:
                  </div>
                  <div className="text-lg">
                    {aiResponse}
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </motion.div>
        </div>
      </section>

      {/* Services Grid */}
      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4">
          <motion.div {...fadeInUp} className="text-center mb-20">
            <h2 className="text-4xl md:text-6xl font-bold text-blue-950 mb-6">আমাদের সেবাসমূহ</h2>
            <div className="w-24 h-2 bg-orange-500 mx-auto rounded-full" />
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-10">
            {SERVICES.map((service, idx) => (
              <motion.div
                key={service.id}
                {...fadeInUp}
                transition={{ delay: idx * 0.1 }}
                whileHover={{ y: -10 }}
                className="bg-gray-50 p-10 rounded-[2.5rem] shadow-sm hover:shadow-xl transition-all border border-gray-100 group"
              >
                <div className="w-16 h-16 bg-blue-100 rounded-2xl flex items-center justify-center text-blue-950 mb-8 group-hover:bg-orange-500 group-hover:text-white transition-colors">
                  <span className="text-3xl">🏗️</span>
                </div>
                <h3 className="text-2xl font-bold mb-4 text-blue-950">{service.title}</h3>
                <p className="text-gray-600 leading-relaxed text-lg">{service.description}</p>
                <button 
                  onClick={() => navigate('/services')}
                  className="mt-8 text-orange-600 font-bold flex items-center group-hover:translate-x-2 transition-transform"
                >
                  আরও দেখুন <ArrowRight size={20} className="ml-2" />
                </button>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Projects */}
      <section className="py-24 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4">
          <motion.div {...fadeInUp} className="flex flex-col md:flex-row justify-between items-end mb-16">
            <div>
              <h2 className="text-4xl md:text-6xl font-bold text-blue-950 mb-4">সেরা প্রকল্পসমূহ</h2>
              <div className="w-24 h-2 bg-orange-500 rounded-full" />
            </div>
            <button 
              onClick={() => navigate('/portfolio')}
              className="mt-8 md:mt-0 bg-blue-950 text-white px-10 py-4 rounded-2xl font-bold hover:bg-orange-500 transition-colors"
            >
              সবগুলো দেখুন
            </button>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
            {PROJECTS.slice(0, 2).map((project, idx) => (
              <motion.div
                key={project.id}
                {...fadeInUp}
                transition={{ delay: idx * 0.1 }}
                className="relative group overflow-hidden rounded-[3rem] h-[500px] shadow-2xl"
              >
                <img 
                  src={project.image} 
                  alt={project.title} 
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-1000"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-blue-950/90 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500 flex flex-col justify-end p-12">
                  <span className="text-orange-500 font-bold mb-4 uppercase tracking-widest">{project.category}</span>
                  <h3 className="text-3xl md:text-4xl font-bold text-white mb-4">{project.title}</h3>
                  <p className="text-gray-300 text-lg mb-8 line-clamp-2">{project.description}</p>
                  <button onClick={() => navigate('/portfolio')} className="text-white font-bold flex items-center group/btn">
                    বিস্তারিত দেখুন <ArrowRight size={20} className="ml-2 group-hover/btn:translate-x-2 transition-transform" />
                  </button>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Final CTA */}
      <section className="py-24 bg-blue-950 text-white">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <motion.h2 {...fadeInUp} className="text-4xl md:text-6xl font-bold mb-8">আজই আপনার প্রজেক্ট শুরু করুন</motion.h2>
          <motion.p {...fadeInUp} className="text-xl text-blue-200 mb-12 max-w-2xl mx-auto">আমাদের এক্সপার্ট টিম আপনার স্বপ্নের বাড়ি নির্মাণে সব সময় পাশে আছে। একটি মেসেজ বা কলেই সমাধান পান।</motion.p>
          <motion.div {...fadeInUp} className="flex flex-col sm:flex-row gap-6 justify-center">
            <button onClick={() => navigate('/contact')} className="bg-orange-500 px-12 py-5 rounded-2xl font-bold text-xl hover:bg-orange-600 transition-all">যোগাযোগ করুন</button>
            <button className="bg-white/10 px-12 py-5 rounded-2xl font-bold text-xl border border-white/20 hover:bg-white/20 transition-all">কল করুন</button>
          </motion.div>
        </div>
      </section>
    </div>
  );
};

export default Home;
