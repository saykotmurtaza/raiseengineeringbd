
import React, { useState } from 'react';
import { motion, AnimatePresence, Variants } from 'framer-motion';
import { ArrowRight, ExternalLink, Filter, MapPin } from 'lucide-react';
import { PROJECTS } from '../constants';

const Portfolio: React.FC = () => {
  const [filter, setFilter] = useState('সবগুলো');
  const categories = ['সবগুলো', 'আবাসিক', 'বাণিজ্যিক', 'ইন্টেরিয়র'];

  const filteredProjects = filter === 'সবগুলো' 
    ? PROJECTS 
    : PROJECTS.filter(p => p.category === filter);

  // Added explicit Variants type to fix ease string literal type mismatch
  const containerVariants: Variants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  // Added explicit Variants type to fix ease string literal type mismatch
  const cardVariants: Variants = {
    hidden: { opacity: 0, y: 30, scale: 0.95 },
    visible: { 
      opacity: 1, 
      y: 0, 
      scale: 1,
      transition: { duration: 0.5, ease: "easeOut" } 
    },
    exit: { opacity: 0, scale: 0.9, transition: { duration: 0.2 } }
  };

  return (
    <div className="pt-24 min-h-screen bg-white">
      {/* Premium Hero Section */}
      <section className="relative py-24 md:py-32 bg-blue-950 overflow-hidden">
        <div className="absolute inset-0">
          <img 
            src="https://images.unsplash.com/photo-1487958449943-2429e8be8625?auto=format&fit=crop&q=80&w=2070" 
            alt="Architecture Background" 
            className="w-full h-full object-cover opacity-20"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-blue-950 via-blue-950/80 to-blue-950" />
        </div>
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center"
          >
            <span className="inline-block px-4 py-1 rounded-full bg-orange-500/20 text-orange-400 font-bold mb-6 border border-orange-500/30 uppercase tracking-widest text-sm">
              নির্মাণে শ্রেষ্ঠত্ব
            </span>
            <h1 className="text-4xl md:text-7xl font-bold text-white mb-8 leading-tight">
              আমাদের <span className="text-orange-500">সেরা প্রকল্পসমূহ</span>
            </h1>
            <p className="text-xl text-blue-100 max-w-3xl mx-auto font-light leading-relaxed">
              আমরা শুধু দালান তৈরি করি না, আমরা আপনার স্বপ্নের নিরাপদ ও নান্দনিক ভিত্তিপ্রস্তর স্থাপন করি। আমাদের প্রতিটি কাজই হলো এক একটি গল্প।
            </p>
          </motion.div>
        </div>
      </section>

      {/* Premium Filtering Section */}
      <section className="sticky top-20 z-40 bg-white/80 backdrop-blur-xl border-b border-gray-100 py-6">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex items-center space-x-2 text-blue-950">
            <Filter size={20} className="text-orange-500" />
            <span className="font-bold text-lg">ফিল্টার করুন:</span>
          </div>
          
          <div className="flex flex-wrap justify-center gap-3">
            {categories.map((cat) => (
              <motion.button
                key={cat}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => setFilter(cat)}
                className={`px-8 py-3 rounded-2xl font-bold transition-all duration-300 ${
                  filter === cat 
                    ? 'bg-orange-500 text-white shadow-lg shadow-orange-500/30' 
                    : 'bg-gray-100 text-gray-700 border border-transparent hover:bg-gray-200'
                }`}
              >
                {cat}
              </motion.button>
            ))}
          </div>
        </div>
      </section>

      {/* Masonry-style Project Grid */}
      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div 
            variants={containerVariants}
            initial="hidden"
            animate="visible"
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-10"
          >
            <AnimatePresence mode="popLayout">
              {filteredProjects.map((project) => (
                <motion.div
                  key={project.id}
                  layout
                  variants={cardVariants}
                  initial="hidden"
                  animate="visible"
                  exit="exit"
                  className="group relative bg-white rounded-[3rem] overflow-hidden shadow-[0_20px_50px_rgba(0,0,0,0.05)] border border-gray-100 flex flex-col h-full"
                >
                  <div className="relative h-80 overflow-hidden">
                    <img 
                      src={project.image} 
                      alt={project.title} 
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-1000"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
                    
                    <div className="absolute top-6 left-6">
                      <span className="bg-white/90 backdrop-blur-md text-blue-950 px-5 py-2 rounded-2xl text-sm font-black shadow-lg">
                        {project.category}
                      </span>
                    </div>

                    <div className="absolute bottom-6 left-6 text-white opacity-0 group-hover:opacity-100 transition-opacity duration-500 transform translate-y-4 group-hover:translate-y-0">
                      <div className="flex items-center space-x-2">
                        <MapPin size={16} className="text-orange-500" />
                        <span className="text-sm font-bold">ঢাকা, বাংলাদেশ</span>
                      </div>
                    </div>
                  </div>

                  <div className="p-10 flex flex-col flex-grow">
                    <h3 className="text-2xl md:text-3xl font-bold text-blue-950 mb-4 leading-tight group-hover:text-orange-600 transition-colors">
                      {project.title}
                    </h3>
                    <p className="text-gray-500 text-lg mb-8 line-clamp-3 leading-relaxed">
                      {project.description}
                    </p>
                    
                    <div className="mt-auto flex items-center justify-between">
                      <button className="flex items-center text-blue-950 font-black text-lg group-hover:text-orange-600 transition-colors">
                        কেস স্টাডি <ArrowRight className="ml-2 group-hover:translate-x-2 transition-transform" size={20} />
                      </button>
                      <div className="w-12 h-12 bg-gray-50 rounded-2xl flex items-center justify-center text-gray-400 group-hover:bg-orange-500 group-hover:text-white transition-all">
                        <ExternalLink size={20} />
                      </div>
                    </div>
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>
          </motion.div>

          {filteredProjects.length === 0 && (
            <div className="text-center py-40">
              <div className="text-6xl mb-6">🔍</div>
              <h3 className="text-3xl font-bold text-blue-950 mb-4">এই ক্যাটাগরিতে কোনো প্রজেক্ট পাওয়া যায়নি</h3>
              <button 
                onClick={() => setFilter('সবগুলো')}
                className="text-orange-600 font-bold underline text-xl"
              >
                সব প্রজেক্ট দেখুন
              </button>
            </div>
          )}
        </div>
      </section>

      {/* Portfolio Stats Section */}
      <section className="py-24 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-white rounded-[4rem] p-12 md:p-24 shadow-2xl flex flex-col md:flex-row items-center justify-around gap-12 text-center border border-gray-100">
            <div>
              <div className="text-6xl font-black text-blue-950 mb-2">৫০০+</div>
              <div className="text-gray-500 text-xl">সফল প্রজেক্ট</div>
            </div>
            <div className="w-[1px] h-20 bg-gray-200 hidden md:block" />
            <div>
              <div className="text-6xl font-black text-orange-500 mb-2">১০০%</div>
              <div className="text-gray-500 text-xl">কাস্টমার স্যাটিসফ্যাকশন</div>
            </div>
            <div className="w-[1px] h-20 bg-gray-200 hidden md:block" />
            <div>
              <div className="text-6xl font-black text-blue-950 mb-2">১২০+</div>
              <div className="text-gray-500 text-xl">স্কিল্ড ইঞ্জিনিয়ার</div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-24 bg-white text-center">
        <div className="max-w-4xl mx-auto px-4">
          <h2 className="text-4xl md:text-5xl font-bold text-blue-950 mb-8">আমাদের পরবর্তী প্রজেক্ট কি আপনার?</h2>
          <p className="text-xl text-gray-500 mb-12">আপনার স্বপ্নের বাড়ি বা অফিস নির্মাণের জন্য আজই আমাদের এক্সপার্ট টিমের সাথে কথা বলুন।</p>
          <button className="bg-blue-950 text-white px-12 py-5 rounded-2xl font-bold text-xl hover:bg-orange-500 transition-all shadow-2xl">
            ফ্রি কনসালটেন্সি শুরু করুন
          </button>
        </div>
      </section>
    </div>
  );
};

export default Portfolio;
