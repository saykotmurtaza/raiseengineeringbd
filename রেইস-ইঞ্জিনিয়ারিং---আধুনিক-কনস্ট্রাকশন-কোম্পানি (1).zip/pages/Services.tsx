
import React from 'react';
import { motion } from 'framer-motion';
import { 
  Home, Building2, Palette, Ruler, Hammer, Truck, 
  CheckCircle2, ArrowRight, ShieldCheck, Zap, HardHat 
} from 'lucide-react';
import { SERVICES, PROCESS_STEPS } from '../constants';

const Services: React.FC = () => {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 30 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.6 } }
  };

  return (
    <div className="pt-24 bg-white">
      {/* Hero Section */}
      <section className="relative py-24 bg-blue-950 overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-0 left-0 w-full h-full bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-orange-500 via-transparent to-transparent scale-150" />
        </div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center">
          <motion.h1 
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="text-4xl md:text-7xl font-bold text-white mb-6"
          >
            আমাদের <span className="text-orange-500">সেবাসমূহ</span>
          </motion.h1>
          <p className="text-xl text-blue-100 max-w-2xl mx-auto font-light">
            আধুনিক আর্কিটেকচার এবং টেকসই ইঞ্জিনিয়ারিংয়ের মাধ্যমে আমরা আপনার প্রতিটি স্বপ্নকে দেই পূর্ণতা।
          </p>
        </div>
      </section>

      {/* Main Services Grid */}
      <section className="py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div 
            variants={containerVariants}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-10"
          >
            {SERVICES.map((service) => (
              <motion.div
                key={service.id}
                variants={itemVariants}
                whileHover={{ y: -10 }}
                className="group p-10 rounded-[3rem] bg-gray-50 border border-gray-100 hover:bg-white hover:shadow-[0_40px_80px_-20px_rgba(0,0,0,0.1)] transition-all duration-500"
              >
                <div className="w-20 h-20 bg-white rounded-2xl flex items-center justify-center text-blue-950 mb-8 shadow-sm group-hover:bg-orange-500 group-hover:text-white transition-all duration-300">
                  {/* Mapping string icon to Lucide components */}
                  {service.id === 1 && <Home size={40} />}
                  {service.id === 2 && <Building2 size={40} />}
                  {service.id === 3 && <Palette size={40} />}
                  {service.id === 4 && <Ruler size={40} />}
                  {service.id === 5 && <Hammer size={40} />}
                  {service.id === 6 && <Truck size={40} />}
                </div>
                <h3 className="text-2xl font-bold text-blue-950 mb-4">{service.title}</h3>
                <p className="text-gray-600 text-lg leading-relaxed mb-8">
                  {service.description}
                </p>
                <button className="flex items-center text-orange-600 font-bold group-hover:translate-x-3 transition-transform">
                  বিস্তারিত জানুন <ArrowRight className="ml-2" size={20} />
                </button>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* Why We Are Premium Section */}
      <section className="py-24 bg-blue-950 text-white relative overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-20 items-center">
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
            >
              <h2 className="text-4xl md:text-5xl font-bold mb-8">কেন রেইস ইঞ্জিনিয়ারিং সেরা?</h2>
              <div className="space-y-6">
                {[
                  { title: 'উচ্চমানের কাঁচামাল', icon: <ShieldCheck className="text-orange-500" /> },
                  { title: 'দক্ষ ইঞ্জিনিয়ারিং টিম', icon: <HardHat className="text-orange-500" /> },
                  { title: 'দ্রুত ডেলিভারি', icon: <Zap className="text-orange-500" /> },
                ].map((item, i) => (
                  <div key={i} className="flex items-center space-x-4 bg-white/5 p-6 rounded-2xl border border-white/10">
                    <div className="p-3 bg-white/10 rounded-xl">{item.icon}</div>
                    <span className="text-xl font-bold">{item.title}</span>
                  </div>
                ))}
              </div>
            </motion.div>
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              className="relative"
            >
              <img 
                src="https://images.unsplash.com/photo-1504307651254-35680f356dfd?auto=format&fit=crop&q=80&w=1000" 
                alt="Construction site" 
                className="rounded-[3rem] shadow-2xl rotate-3"
              />
            </motion.div>
          </div>
        </div>
      </section>

      {/* Process Section */}
      <section className="py-24 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-20">
            <h2 className="text-4xl md:text-6xl font-bold text-blue-950 mb-6">কিভাবে আমরা কাজ করি</h2>
            <p className="text-gray-600 text-xl">৪টি সহজ ধাপে আপনার প্রজেক্ট বাস্তবায়ন</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            {PROCESS_STEPS.map((step, idx) => (
              <motion.div
                key={idx}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: idx * 0.1 }}
                className="text-center bg-white p-10 rounded-[2.5rem] shadow-sm border border-gray-100 h-full flex flex-col items-center"
              >
                <div className={`w-16 h-16 ${step.color} rounded-2xl flex items-center justify-center text-white mb-6 shadow-lg`}>
                  <step.icon size={30} />
                </div>
                <h3 className="text-2xl font-bold text-blue-950 mb-4">{step.title}</h3>
                <p className="text-gray-500">{step.desc}</p>
                <div className="mt-auto pt-6 text-gray-200 text-6xl font-black">0{idx + 1}</div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-24 bg-white">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div 
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            className="bg-gradient-to-br from-orange-500 to-red-600 rounded-[3.5rem] p-12 md:p-20 text-center text-white shadow-2xl"
          >
            <h2 className="text-4xl md:text-6xl font-bold mb-8">আপনি কি প্রস্তুত?</h2>
            <p className="text-xl mb-12 opacity-90 leading-relaxed">
              আপনার স্বপ্নের প্রজেক্ট নিয়ে আজই আমাদের সাথে পরামর্শ করুন। রেইস ইঞ্জিনিয়ারিং আপনার পাশে আছে।
            </p>
            <div className="flex flex-col sm:flex-row justify-center gap-6">
              <button className="bg-white text-orange-600 px-12 py-5 rounded-2xl font-bold text-xl hover:bg-gray-100 transition-all flex items-center justify-center">
                ফ্রি কোটেশন নিন
              </button>
              <button className="bg-blue-950 text-white px-12 py-5 rounded-2xl font-bold text-xl hover:bg-black transition-all">
                কল করুন
              </button>
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  );
};

export default Services;
