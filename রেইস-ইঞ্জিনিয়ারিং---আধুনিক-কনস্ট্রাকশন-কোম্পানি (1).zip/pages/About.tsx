
import React, { useRef } from 'react';
import { motion, useScroll, useTransform, Variants } from 'framer-motion';
import { 
  Target, Eye, Heart, ShieldCheck, Award, 
  Users, CheckCircle2, History, Briefcase, Globe 
} from 'lucide-react';

const About: React.FC = () => {
  const containerRef = useRef(null);
  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ["start start", "end end"]
  });

  const heroScale = useTransform(scrollYProgress, [0, 0.2], [1, 1.1]);
  const heroOpacity = useTransform(scrollYProgress, [0, 0.2], [1, 0]);

  const fadeInUp: Variants = {
    hidden: { opacity: 0, y: 40 },
    visible: { 
      opacity: 1, 
      y: 0,
      transition: { duration: 0.8, ease: "easeOut" }
    }
  };

  const staggerContainer: Variants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2
      }
    }
  };

  return (
    <div ref={containerRef} className="bg-white overflow-hidden">
      {/* 1. Immersive Hero Section with Parallax */}
      <section className="relative h-screen flex items-center justify-center overflow-hidden">
        <motion.div 
          style={{ scale: heroScale }}
          className="absolute inset-0 z-0"
        >
          <img 
            src="https://images.unsplash.com/photo-1541913057815-9984b242e230?auto=format&fit=crop&q=80&w=2000" 
            className="w-full h-full object-cover"
            alt="Engineering Background"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-blue-950/80 via-blue-950/60 to-white" />
        </motion.div>

        <motion.div 
          style={{ opacity: heroOpacity }}
          className="relative z-10 text-center px-4"
        >
          <motion.span 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="inline-block px-6 py-2 rounded-full bg-orange-500 text-white font-bold mb-6 tracking-widest uppercase text-sm"
          >
            প্রতিষ্ঠিত ২০১৪
          </motion.span>
          <motion.h1 
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 1 }}
            className="text-5xl md:text-9xl font-black text-white mb-8 leading-none"
          >
            আমাদের <br /> <span className="text-orange-500">গল্প</span>
          </motion.h1>
          <motion.p 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.5 }}
            className="text-xl md:text-3xl text-blue-50 max-w-3xl mx-auto font-light leading-relaxed"
          >
            এক দশক ধরে আমরা শুধু ভবন নয়, মানুষের আস্থা আর স্বপ্ন বুনে চলেছি।
          </motion.p>
        </motion.div>

        <motion.div 
          animate={{ y: [0, 20, 0] }}
          transition={{ repeat: Infinity, duration: 2 }}
          className="absolute bottom-10 left-1/2 -translate-x-1/2 text-white flex flex-col items-center"
        >
          <span className="text-sm font-bold mb-2 uppercase tracking-widest opacity-50">নিচে দেখুন</span>
          <div className="w-[1px] h-16 bg-gradient-to-b from-white to-transparent" />
        </motion.div>
      </section>

      {/* 2. Strategic Vision Section */}
      <section className="py-32 relative bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-24 items-center">
            <motion.div
              variants={fadeInUp}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true }}
              className="relative"
            >
              <div className="absolute -top-10 -left-10 w-40 h-40 bg-orange-500/10 rounded-full blur-3xl" />
              <h2 className="text-4xl md:text-6xl font-black text-blue-950 mb-10 leading-tight">
                আমরা কেন <br /> <span className="text-orange-500">আলাদা?</span>
              </h2>
              <p className="text-xl text-gray-600 mb-12 leading-relaxed">
                রেইস ইঞ্জিনিয়ারিং শুধু একটি নাম নয়, এটি একটি প্রতিশ্রুতি। আমরা বিশ্বাস করি প্রতিটি ইটের পেছনে থাকে একটি স্বপ্ন, আর সেই স্বপ্নকে সুরক্ষিত রাখাই আমাদের মূল লক্ষ্য। আধুনিক আর্কিটেকচার এবং সিভিল ইঞ্জিনিয়ারিংয়ের নিখুঁত সংমিশ্রণে আমরা তৈরি করি আগামীর স্থাপত্য।
              </p>
              
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-8">
                <div className="flex items-center space-x-4">
                  <div className="p-4 bg-blue-50 text-blue-600 rounded-2xl">
                    <History size={28} />
                  </div>
                  <span className="text-lg font-bold text-blue-950">১০ বছরের অভিজ্ঞতা</span>
                </div>
                <div className="flex items-center space-x-4">
                  <div className="p-4 bg-orange-50 text-orange-600 rounded-2xl">
                    <Globe size={28} />
                  </div>
                  <span className="text-lg font-bold text-blue-950">আধুনিক গ্লোবাল স্ট্যান্ডার্ড</span>
                </div>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, scale: 0.8, rotate: -5 }}
              whileInView={{ opacity: 1, scale: 1, rotate: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 1 }}
              className="relative"
            >
              <div className="relative z-10 rounded-[4rem] overflow-hidden shadow-2xl">
                <img 
                  src="https://images.unsplash.com/photo-1504307651254-35680f356dfd?auto=format&fit=crop&q=80&w=1000" 
                  alt="Construction work"
                  className="w-full h-[600px] object-cover"
                />
              </div>
              <div className="absolute -bottom-10 -right-10 bg-orange-500 text-white p-12 rounded-[3rem] shadow-xl z-20 hidden md:block">
                <div className="text-5xl font-black mb-2">৫০০+</div>
                <div className="text-lg font-bold opacity-80 uppercase tracking-widest">প্রজেক্ট সম্পন্ন</div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* 3. Core Values Grid with Modern Hover */}
      <section className="py-32 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div 
            variants={fadeInUp}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            className="text-center mb-24"
          >
            <h2 className="text-4xl md:text-7xl font-black text-blue-950 mb-8">আমাদের মূল শক্তি</h2>
            <p className="text-xl text-gray-500 max-w-2xl mx-auto">এই নীতিগুলোই আমাদের এগিয়ে চলার প্রেরণা জোগায়</p>
          </motion.div>

          <motion.div 
            variants={staggerContainer}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8"
          >
            {[
              { title: 'উদ্ভাবন', desc: 'নতুন প্রযুক্তি আর নকশায় আমরা সবসময় এক ধাপ এগিয়ে।', icon: <Target className="text-white" />, color: 'bg-blue-600' },
              { title: 'স্বচ্ছতা', desc: 'কাজের প্রতিটি ধাপে আমরা শতভাগ সততা নিশ্চিত করি।', icon: <Eye className="text-white" />, color: 'bg-orange-600' },
              { title: 'নিরাপত্তা', desc: 'আমাদের প্রজেক্টে সুরক্ষা এবং মজবুত অবকাঠামোই প্রথম প্রাধান্য।', icon: <ShieldCheck className="text-white" />, color: 'bg-green-600' },
              { title: 'প্যাশন', desc: 'আমরা কাজ করি হৃদয় দিয়ে, প্রতিটি স্থাপনায় থাকে মমতা।', icon: <Heart className="text-white" />, color: 'bg-red-600' }
            ].map((value, i) => (
              <motion.div
                key={i}
                variants={fadeInUp}
                whileHover={{ y: -15 }}
                className="bg-white p-12 rounded-[3rem] shadow-sm hover:shadow-2xl transition-all duration-500 group"
              >
                <div className={`w-16 h-16 ${value.color} rounded-2xl flex items-center justify-center mb-8 shadow-lg group-hover:scale-110 transition-transform`}>
                  {value.icon}
                </div>
                <h3 className="text-2xl font-bold text-blue-950 mb-4">{value.title}</h3>
                <p className="text-gray-500 leading-relaxed text-lg">{value.desc}</p>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* 4. Leadership Section */}
      <section className="py-32 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row justify-between items-end mb-20 gap-8">
            <motion.div
              variants={fadeInUp}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true }}
            >
              <h2 className="text-4xl md:text-7xl font-black text-blue-950 mb-4">নেতৃত্বে দক্ষ <br /> <span className="text-orange-500">প্রকৌশলী</span></h2>
              <div className="w-32 h-3 bg-orange-500 rounded-full" />
            </motion.div>
            <p className="text-xl text-gray-500 max-w-md">আমাদের টিমে আছেন দেশের সেরা সব সিভিল ইঞ্জিনিয়ার এবং আর্কিটেক্টবৃন্দ।</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
            {[
              { name: 'ইঞ্জিঃ রফিকুল ইসলাম', role: 'প্রতিষ্ঠাতা ও সিইও', img: 'https://images.unsplash.com/photo-1560250097-0b93528c311a?auto=format&fit=crop&q=80&w=400' },
              { name: 'আর্কঃ সাদিয়া রহমান', role: 'প্রধান আর্কিটেক্ট', img: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&q=80&w=400' },
              { name: 'ইঞ্জিঃ তানভীর আহমেদ', role: 'প্রজেক্ট ডিরেক্টর', img: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&q=80&w=400' }
            ].map((member, idx) => (
              <motion.div
                key={idx}
                variants={fadeInUp}
                initial="hidden"
                whileInView="visible"
                viewport={{ once: true }}
                transition={{ delay: idx * 0.2 }}
                className="group relative overflow-hidden rounded-[3.5rem] bg-gray-100"
              >
                <img 
                  src={member.img} 
                  alt={member.name}
                  className="w-full h-[500px] object-cover grayscale group-hover:grayscale-0 group-hover:scale-105 transition-all duration-700"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-blue-950 via-transparent to-transparent opacity-90 p-10 flex flex-col justify-end">
                  <h4 className="text-3xl font-bold text-white mb-2">{member.name}</h4>
                  <p className="text-orange-400 font-bold uppercase tracking-widest text-sm">{member.role}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* 5. Achievement Timeline - Horizontal Scroll Hint */}
      <section className="py-32 bg-blue-950 text-white overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="absolute top-0 right-0 p-20 opacity-5">
            <Award size={400} />
          </div>
          
          <motion.div
            variants={fadeInUp}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            className="mb-20"
          >
            <h2 className="text-4xl md:text-7xl font-black mb-8">সাফল্যের <span className="text-orange-500">কালক্রম</span></h2>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-12 relative z-10">
            {[
              { year: '২০১৪', event: 'কোম্পানির যাত্রা শুরু এক ঝাক তরুণ ইঞ্জিনিয়ার নিয়ে।', icon: <Briefcase /> },
              { year: '২০১৭', event: '১০০তম প্রজেক্ট সফলভাবে হ্যান্ডওভার।', icon: <CheckCircle2 /> },
              { year: '২০২০', event: 'সেরা কনস্ট্রাকশন কোম্পানি হিসেবে ন্যাশনাল অ্যাওয়ার্ড লাভ।', icon: <Award /> },
              { year: '২০২৪', event: 'পুরো বাংলাদেশে ৫টি নতুন শাখা অফিস উদ্বোধন।', icon: <Users /> }
            ].map((milestone, idx) => (
              <motion.div
                key={idx}
                initial={{ opacity: 0, x: 50 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ delay: idx * 0.2 }}
                className="relative pl-12 border-l-2 border-orange-500/30 pb-12 last:pb-0"
              >
                <div className="absolute left-[-9px] top-0 w-4 h-4 rounded-full bg-orange-500 shadow-[0_0_15px_rgba(249,115,22,0.5)]" />
                <div className="text-5xl font-black text-orange-500 mb-4">{milestone.year}</div>
                <div className="text-xl font-bold mb-4 flex items-center space-x-2">
                   <span className="opacity-50">{milestone.icon}</span>
                </div>
                <p className="text-blue-100/70 text-lg leading-relaxed">{milestone.event}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* 6. Modern CTA Section */}
      <section className="py-32 bg-white text-center">
        <div className="max-w-5xl mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="bg-gradient-to-br from-orange-500 to-red-600 rounded-[4rem] p-16 md:p-24 shadow-2xl relative overflow-hidden group"
          >
            <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] opacity-10" />
            <h2 className="text-4xl md:text-7xl font-black text-white mb-10 relative z-10">আমাদের টিমে যোগ দিন</h2>
            <p className="text-xl text-white/90 mb-12 max-w-2xl mx-auto relative z-10 font-light">
              আমরা সবসময় নতুন প্রতিভা আর সৃজনশীল মস্তিষ্কের সন্ধান করি। আপনি কি আপনার ইঞ্জিনিয়ারিং ক্যারিয়ারকে নতুন উচ্চতায় নিয়ে যেতে চান?
            </p>
            <motion.button 
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="bg-blue-950 text-white px-12 py-6 rounded-2xl font-black text-xl hover:bg-black transition-all shadow-2xl relative z-10"
            >
              ক্যারিয়ার দেখুন
            </motion.button>
          </motion.div>
        </div>
      </section>
    </div>
  );
};

export default About;
