
import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { MapPin, Phone, Mail, Send, CheckCircle } from 'lucide-react';
import { CONTACT_INFO } from '../constants';

const Contact: React.FC = () => {
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Simulate API call
    setSubmitted(true);
    setTimeout(() => setSubmitted(false), 5000);
  };

  return (
    <div className="pt-24 pb-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h1 className="text-4xl md:text-5xl font-bold text-blue-900 mb-6">যোগাযোগ করুন</h1>
          <p className="text-gray-600 max-w-2xl mx-auto">আপনার যেকোনো জিজ্ঞাসা বা প্রজেক্ট নিয়ে আলোচনার জন্য আমাদের মেসেজ দিন।</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
          {/* Contact Form */}
          <motion.div 
            initial={{ opacity: 0, x: -30 }}
            animate={{ opacity: 1, x: 0 }}
            className="bg-white rounded-3xl p-8 md:p-12 shadow-2xl border border-gray-100"
          >
            {submitted ? (
              <div className="h-full flex flex-col items-center justify-center text-center py-12">
                <div className="w-20 h-20 bg-green-100 text-green-600 rounded-full flex items-center justify-center mb-6">
                  <CheckCircle size={48} />
                </div>
                <h3 className="text-3xl font-bold text-gray-800 mb-4">ধন্যবাদ!</h3>
                <p className="text-gray-600 text-lg">আপনার মেসেজটি আমরা পেয়েছি। খুব শীঘ্রই আমাদের প্রতিনিধি আপনার সাথে যোগাযোগ করবেন।</p>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-gray-700 font-bold mb-2">আপনার নাম</label>
                    <input type="text" required className="w-full p-4 rounded-xl border border-gray-200 focus:border-orange-500 outline-none transition-all" placeholder="নাম লিখুন" />
                  </div>
                  <div>
                    <label className="block text-gray-700 font-bold mb-2">ইমেইল</label>
                    <input type="email" required className="w-full p-4 rounded-xl border border-gray-200 focus:border-orange-500 outline-none transition-all" placeholder="example@mail.com" />
                  </div>
                </div>
                <div>
                  <label className="block text-gray-700 font-bold mb-2">বিষয়</label>
                  <input type="text" required className="w-full p-4 rounded-xl border border-gray-200 focus:border-orange-500 outline-none transition-all" placeholder="মেসেজের বিষয়" />
                </div>
                <div>
                  <label className="block text-gray-700 font-bold mb-2">আপনার মেসেজ</label>
                  <textarea rows={5} required className="w-full p-4 rounded-xl border border-gray-200 focus:border-orange-500 outline-none transition-all" placeholder="এখানে বিস্তারিত লিখুন..."></textarea>
                </div>
                <button type="submit" className="w-full bg-blue-900 hover:bg-orange-500 text-white font-bold py-4 rounded-xl shadow-lg transition-all flex items-center justify-center text-lg">
                  মেসেজ পাঠান <Send className="ml-2" size={20} />
                </button>
              </form>
            )}
          </motion.div>

          {/* Contact Info & Map */}
          <motion.div 
            initial={{ opacity: 0, x: 30 }}
            animate={{ opacity: 1, x: 0 }}
            className="space-y-12"
          >
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="bg-blue-50 p-8 rounded-3xl border border-blue-100">
                <MapPin className="text-orange-500 mb-4" size={32} />
                <h3 className="text-xl font-bold text-blue-950 mb-2">অফিসের ঠিকানা</h3>
                <p className="text-gray-600">{CONTACT_INFO.address}</p>
              </div>
              <div className="bg-orange-50 p-8 rounded-3xl border border-orange-100">
                <Phone className="text-blue-900 mb-4" size={32} />
                <h3 className="text-xl font-bold text-blue-950 mb-2">ফোন করুন</h3>
                <p className="text-gray-600">{CONTACT_INFO.phone}</p>
              </div>
              <div className="bg-green-50 p-8 rounded-3xl border border-green-100">
                <Mail className="text-green-600 mb-4" size={32} />
                <h3 className="text-xl font-bold text-blue-950 mb-2">ইমেইল</h3>
                <p className="text-gray-600">{CONTACT_INFO.email}</p>
              </div>
              <div className="bg-purple-50 p-8 rounded-3xl border border-purple-100">
                <div className="text-purple-600 mb-4 font-bold">Open</div>
                <h3 className="text-xl font-bold text-blue-950 mb-2">অফিস আওয়ার</h3>
                <p className="text-gray-600">{CONTACT_INFO.openingHours}</p>
              </div>
            </div>

            <div className="rounded-3xl overflow-hidden shadow-xl h-[300px] border-4 border-white">
              {/* Map Placeholder */}
              <iframe 
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d14602.254272231175!2d90.4125181!3d23.7915!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3755c7a0f70deb73%3A0x30c3642c3d39ef51!2sBanani%2C%20Dhaka!5e0!3m2!1sen!2sbd!4v1622543958933!5m2!1sen!2sbd" 
                width="100%" 
                height="100%" 
                style={{ border: 0 }} 
                allowFullScreen={true} 
                loading="lazy"
              ></iframe>
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
};

export default Contact;
