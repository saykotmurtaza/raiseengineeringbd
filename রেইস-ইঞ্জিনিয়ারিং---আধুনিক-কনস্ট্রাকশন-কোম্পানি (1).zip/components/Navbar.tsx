
import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X, HardHat } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { NAV_ITEMS } from '../constants';

const Navbar: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const location = useLocation();

  const isHomePage = location.pathname === '/';

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Determine navbar background class
  const navBgClass = isHomePage 
    ? (scrolled ? 'bg-white shadow-lg py-2' : 'bg-transparent py-4')
    : 'bg-white shadow-md py-2';

  // Determine text color for the logo/brand
  const brandTextColor = isHomePage 
    ? (scrolled ? 'text-blue-900' : 'text-white')
    : 'text-blue-900';

  // Determine general link color
  const linkColorClass = (itemPath: string) => {
    const isActive = location.pathname === itemPath;
    if (isActive) return 'text-orange-500 border-b-2 border-orange-500';
    
    if (isHomePage) {
      return scrolled ? 'text-gray-700 hover:text-orange-500' : 'text-white hover:text-orange-200';
    }
    
    return 'text-gray-700 hover:text-orange-500';
  };

  return (
    <nav className={`fixed w-full z-50 transition-all duration-300 ${navBgClass}`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <Link to="/" className="flex items-center space-x-2">
            <motion.div
              whileHover={{ rotate: 15 }}
              className="bg-orange-500 p-2 rounded-lg"
            >
              <HardHat className="text-white w-8 h-8" />
            </motion.div>
            <span className={`text-2xl font-bold tracking-tight transition-colors duration-300 ${brandTextColor}`}>
              রেইস <span className="text-orange-500">ইঞ্জিনিয়ারিং</span>
            </span>
          </Link>

          {/* Desktop Menu */}
          <div className="hidden md:flex space-x-8">
            {NAV_ITEMS.map((item) => (
              <Link
                key={item.path}
                to={item.path}
                className={`text-lg font-medium transition-all duration-300 ${linkColorClass(item.path)}`}
              >
                {item.label}
              </Link>
            ))}
          </div>

          {/* Mobile Menu Button */}
          <div className="md:hidden">
            <button
              onClick={() => setIsOpen(!isOpen)}
              className={`${isHomePage && !scrolled ? 'text-white' : 'text-blue-900'}`}
            >
              {isOpen ? <X size={28} /> : <Menu size={28} />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu Overlay */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="md:hidden bg-white shadow-xl"
          >
            <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3 flex flex-col items-center">
              {NAV_ITEMS.map((item) => (
                <Link
                  key={item.path}
                  to={item.path}
                  onClick={() => setIsOpen(false)}
                  className={`block px-3 py-4 text-xl font-medium w-full text-center border-b border-gray-100 ${
                    location.pathname === item.path ? 'text-orange-500 bg-orange-50' : 'text-gray-700'
                  }`}
                >
                  {item.label}
                </Link>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
};

export default Navbar;
