
import React from 'react';
import { Facebook, Twitter, Instagram, Linkedin, Mail, Phone, MapPin } from 'lucide-react';
import { CONTACT_INFO, NAV_ITEMS } from '../constants';

const Footer: React.FC = () => {
  return (
    <footer className="bg-blue-950 text-white pt-16 pb-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid grid-cols-1 md:grid-cols-4 gap-12">
        {/* Company Info */}
        <div className="space-y-4">
          <h2 className="text-2xl font-bold">রেইস <span className="text-orange-500">ইঞ্জিনিয়ারিং</span></h2>
          <p className="text-gray-400 leading-relaxed">
            আমরা গত ১০ বছর ধরে বাংলাদেশে আধুনিক ও নিরাপদ অবকাঠামো নির্মাণে বিশ্বস্ততার সাথে কাজ করে আসছি। আমাদের লক্ষ্য আপনার স্বপ্নকে বাস্তবে রূপ দেওয়া।
          </p>
          <div className="flex space-x-4">
            <a href="#" className="p-2 bg-blue-900 rounded-full hover:bg-orange-500 transition-colors"><Facebook size={18} /></a>
            <a href="#" className="p-2 bg-blue-900 rounded-full hover:bg-orange-500 transition-colors"><Twitter size={18} /></a>
            <a href="#" className="p-2 bg-blue-900 rounded-full hover:bg-orange-500 transition-colors"><Instagram size={18} /></a>
            <a href="#" className="p-2 bg-blue-900 rounded-full hover:bg-orange-500 transition-colors"><Linkedin size={18} /></a>
          </div>
        </div>

        {/* Quick Links */}
        <div>
          <h3 className="text-xl font-bold mb-6 border-b-2 border-orange-500 w-16 pb-2">লিঙ্কসমূহ</h3>
          <ul className="space-y-3">
            {NAV_ITEMS.map((item) => (
              <li key={item.path}>
                <a href={item.path} className="text-gray-400 hover:text-orange-500 transition-colors flex items-center">
                  <span className="mr-2">›</span> {item.label}
                </a>
              </li>
            ))}
          </ul>
        </div>

        {/* Services */}
        <div>
          <h3 className="text-xl font-bold mb-6 border-b-2 border-orange-500 w-16 pb-2">সেবাসমূহ</h3>
          <ul className="space-y-3 text-gray-400">
            <li>আবাসিক নির্মাণ</li>
            <li>বাণিজ্যিক ভবন</li>
            <li>ইন্টেরিয়র ডিজাইন</li>
            <li>সংস্কার কাজ</li>
            <li>ইঞ্জিনিয়ারিং প্ল্যানিং</li>
          </ul>
        </div>

        {/* Contact Info */}
        <div className="space-y-4">
          <h3 className="text-xl font-bold mb-6 border-b-2 border-orange-500 w-16 pb-2">যোগাযোগ</h3>
          <div className="flex items-start space-x-3 text-gray-400">
            <MapPin className="text-orange-500 mt-1" size={20} />
            <p>{CONTACT_INFO.address}</p>
          </div>
          <div className="flex items-center space-x-3 text-gray-400">
            <Phone className="text-orange-500" size={20} />
            <p>{CONTACT_INFO.phone}</p>
          </div>
          <div className="flex items-center space-x-3 text-gray-400">
            <Mail className="text-orange-500" size={20} />
            <p>{CONTACT_INFO.email}</p>
          </div>
        </div>
      </div>

      <div className="border-t border-gray-800 mt-16 pt-8 text-center text-gray-500">
        <p>&copy; {new Date().getFullYear()} রেইস ইঞ্জিনিয়ারিং। সর্বস্বত্ব সংরক্ষিত।</p>
      </div>
    </footer>
  );
};

export default Footer;
