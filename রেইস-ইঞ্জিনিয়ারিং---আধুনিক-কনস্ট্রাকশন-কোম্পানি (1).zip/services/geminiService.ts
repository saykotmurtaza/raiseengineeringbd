
import { GoogleGenAI } from "@google/genai";

export const getConstructionAdvice = async (query: string) => {
  try {
    // Initializing the AI client
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    
    // Setting up the prompt with specific personality and instructions
    const prompt = `আপনি রেইস ইঞ্জিনিয়ারিং (Raise Engineering) কোম্পানির একজন এক্সপার্ট সিভিল ইঞ্জিনিয়ার। 
    ব্যবহারকারী আপনাকে একটি প্রশ্ন করেছেন: "${query}"। 
    
    অনুগ্রহ করে নিচের নিয়মগুলো মেনে উত্তর দিন:
    ১. উত্তরটি সম্পূর্ণ বাংলায় দিন।
    ২. উত্তরটি সহজবোধ্য এবং বুলেটেড পয়েন্টে সাজিয়ে লিখুন।
    ৩. যদি সম্ভব হয়, একটি প্রাথমিক খরচের আইডিয়া দিন।
    ৪. শেষে আমাদের সাথে সরাসরি যোগাযোগের জন্য উৎসাহ দিন।
    
    উত্তর দিন:`;

    // Updated generateContent call to use the direct string prompt as per recommended patterns
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
      config: {
        temperature: 0.7,
        maxOutputTokens: 800,
      }
    });

    // Directly accessing the .text property as per guidelines
    return response.text || "দুঃখিত, আমি উত্তরটি তৈরি করতে পারছি না। দয়া করে আবার চেষ্টা করুন।";
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "সার্ভারে সমস্যা হচ্ছে। দয়া করে কিছুক্ষণ পর আবার চেষ্টা করুন।";
  }
};
